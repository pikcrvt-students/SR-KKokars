//
//
//

#ifndef ROGUELIKE_PLAYER_INP_H
#define ROGUELIKE_PLAYER_INP_H
#include <iostream>
#include <string>

void player_inp(bool* quit, int* p_x, int* p_y, bool* gen, int* level);


#endif //ROGUELIKE_PLAYER_INP_H
